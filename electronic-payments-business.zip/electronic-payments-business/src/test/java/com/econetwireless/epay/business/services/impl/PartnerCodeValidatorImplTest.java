package com.econetwireless.epay.business.services.impl;

import static org.mockito.Mockito.mock;

import com.econetwireless.epay.dao.requestpartner.api.RequestPartnerDao;
import org.junit.jupiter.api.Test;

class PartnerCodeValidatorImplTest {
    @Test
    void testConstructor() {
        // TODO: This test is incomplete.
        //   Reason: R002 Missing observers.
        //   Diffblue Cover was unable to create an assertion.
        //   Add getters for the following fields or make them package-private:
        //     PartnerCodeValidatorImpl.requestPartnerDao

        new PartnerCodeValidatorImpl(mock(RequestPartnerDao.class));
    }

    @Test
    void testConstructor2() {
        // TODO: This test is incomplete.
        //   Reason: R002 Missing observers.
        //   Diffblue Cover was unable to create an assertion.
        //   Add getters for the following fields or make them package-private:
        //     PartnerCodeValidatorImpl.requestPartnerDao

        new PartnerCodeValidatorImpl(mock(RequestPartnerDao.class));
    }
}

